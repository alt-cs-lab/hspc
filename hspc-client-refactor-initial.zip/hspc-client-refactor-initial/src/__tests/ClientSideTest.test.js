 test('should do something',function(){
    //Base Test
}); 
 //   This is the skeleton of how tests work

