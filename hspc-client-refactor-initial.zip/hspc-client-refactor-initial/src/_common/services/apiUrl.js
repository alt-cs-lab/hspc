const API_URL = window.location.origin + '/api';

export default API_URL;